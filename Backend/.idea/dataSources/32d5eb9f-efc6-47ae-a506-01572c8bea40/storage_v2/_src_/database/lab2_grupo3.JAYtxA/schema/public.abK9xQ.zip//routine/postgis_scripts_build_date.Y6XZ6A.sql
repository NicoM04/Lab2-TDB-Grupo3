create function postgis_scripts_build_date() returns text
    immutable
    language sql
as
$$SELECT '2025-01-19 06:58:55'::text AS version$$;

alter function postgis_scripts_build_date() owner to postgres;

