create function validar_detalle_pedido() returns trigger
    language plpgsql
as
$$
DECLARE
    v_categoria VARCHAR(50);
    v_urgente BOOLEAN;
    v_id_repartidor INT;
    v_entregas INT;
BEGIN
    -- Obtener categoría del producto
    SELECT categoria INTO v_categoria
    FROM ProductoServicio
    WHERE id_producto = NEW.id_producto;

    -- Obtener si el pedido es urgente y el id_repartidor
    SELECT urgente, id_repartidor
    INTO v_urgente, v_id_repartidor
    FROM Pedido
    WHERE id_pedido = NEW.id_pedido;

    -- Obtener cantidad de entregas del repartidor
    SELECT cantidad_entregas INTO v_entregas
    FROM Repartidores
    WHERE id_repartidor = v_id_repartidor;

    -- Validaciones específicas por categoría
    IF v_categoria = 'Documento Legal' THEN
        IF NOT v_urgente THEN
            RAISE EXCEPTION 'Los documentos legales solo pueden enviarse con pedidos urgentes.';
        END IF;
        IF NEW.cantidad > 1 THEN
            RAISE EXCEPTION 'Solo se permite una unidad por pedido para documentos legales.';
        END IF;

    ELSIF v_categoria = 'Certificado Oficial' THEN
        IF v_entregas < 5 THEN
            RAISE EXCEPTION 'El repartidor debe tener al menos 5 entregas para transportar certificados oficiales.';
        END IF;
        IF NEW.cantidad > 1 THEN
            RAISE EXCEPTION 'Solo se permite una unidad por pedido para certificados oficiales.';
        END IF;
    END IF;

    RETURN NEW;
END;
$$;

alter function validar_detalle_pedido() owner to postgres;

