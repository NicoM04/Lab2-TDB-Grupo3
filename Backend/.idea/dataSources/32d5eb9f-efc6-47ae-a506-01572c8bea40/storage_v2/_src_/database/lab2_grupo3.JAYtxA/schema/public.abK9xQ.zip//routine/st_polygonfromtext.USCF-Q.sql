create function st_polygonfromtext(text, integer) returns geometry
    immutable
    strict
    parallel safe
    cost 250
    language sql
as
$$SELECT public.ST_PolyFromText($1, $2)$$;

alter function st_polygonfromtext(text, integer) owner to postgres;

