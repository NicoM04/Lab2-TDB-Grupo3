create function actualizar_fecha_entrega() returns trigger
    language plpgsql
as
$$
BEGIN
    -- Si el nuevo estado es 'Entregado' y antes no lo era
    IF NEW.estado = 'Entregado' AND (OLD.estado IS DISTINCT FROM 'Entregado') THEN
        NEW.fecha_entrega := CURRENT_DATE;
    END IF;

    RETURN NEW;
END;
$$;

alter function actualizar_fecha_entrega() owner to postgres;

